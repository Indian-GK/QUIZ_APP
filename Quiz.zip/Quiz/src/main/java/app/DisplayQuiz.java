package app;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;

@WebServlet("/DisplayQuiz")
public class DisplayQuiz extends HttpServlet 
{
	private static final long serialVersionUID = 1L;
	
	final String DB_URL = "jdbc:mysql://localhost:3306/QUIZ_APP";
    final String USER = "Gokul";
    final String PASS = "";
    
    String idString= CheckingId.userId;

        
	@SuppressWarnings("unchecked")
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		
    PrintWriter out = response.getWriter();

				try 
				{  
					String sql = "SELECT Q_NO,Question,OPTION1,OPTION2,OPTION3,OPTION4,ANSWER FROM QUESTIONS where USER_ADMIN = ?";
					Class.forName("com.mysql.jdbc.Driver");	
					
		            Connection con = DriverManager.getConnection(DB_URL,USER,PASS);
		            PreparedStatement pStatement = con.prepareStatement(sql);
	                pStatement.setString(1,idString);
		      	    ResultSet rs=pStatement.executeQuery();
		      	
		      	   JSONObject obj2=new JSONObject();
		    	   JSONArray arr=new JSONArray();
		    	   
		      while(rs.next()) 
		      {

		    	  JSONObject obj = new JSONObject();
		    
		    	  obj.put("qno",rs.getInt(1));
		    	  obj.put("question",rs.getString(2));
		    	  obj.put("option1",rs.getString(3));
		    	  obj.put("option2",rs.getString(4));
		    	  obj.put("option3",rs.getString(5));
		    	  obj.put("option4",rs.getString(6));
		    	  obj.put("answer",rs.getString(7));
		    	 
		    	  arr.add(obj);
		      }
		     
		      obj2.put("value",arr);
		      
		      	out.print(obj2);
				}
				catch (SQLException e) 
				{
					out.print("Please give a Valid ZS Joining ID !");
				} catch (Exception e) 
				{
					out.print("Oops something went wrong,try again");
				}
		}
//		protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
//	{
//	doPost(request,response);
//	}
		
	}

