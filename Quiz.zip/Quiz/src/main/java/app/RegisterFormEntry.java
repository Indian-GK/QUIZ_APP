package app;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.*;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.json.simple.JSONObject;

@WebServlet("/RegisterFormEntry")
public class RegisterFormEntry extends HttpServlet 
{
	private static final long serialVersionUID = 1L;
	
       String name;
       public static String id;
       String dob;
       String school;
       java.sql.Date date;
       JSONObject object = new JSONObject();
   

    public static java.sql.Date getCurrentDatetime() 
    {
        java.util.Date today = new java.util.Date();
        return new java.sql.Date(today.getTime());
    }
    
	
	@SuppressWarnings("unchecked")
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
	{
			
			name=request.getParameter("name");
			id=request.getParameter("id");
			school=request.getParameter("school");
			dob=request.getParameter("birthday");
			date = getCurrentDatetime();
			
			
			PrintWriter out = response.getWriter();
			
			if(name.equals("")||id.equals("")||school.equals("")||dob.equals("")) 
			{
				object.put("error","The Column's can't be left blank !");
			}
			else 
			{
				try 
				{
					Class.forName("com.mysql.cj.jdbc.Driver");
				    Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/QUIZ_APP","Gokul","");
				    
				    
				    
				    PreparedStatement ps = con.prepareStatement("INSERT INTO StudentDetails(STUDENT_NAME,DOB,ZS_ID,SCHOOL_NAME,REGISTERED_TIME) VALUES(?,?,?,?,?)");
				    
				    ps.setString(1,name);
				    ps.setString(2,dob);
				    ps.setString(3,id);
				    ps.setString(4,school);
				    ps.setDate(5,date);
				    
				    
				    ps.executeUpdate();
				    object.put("status","Success");		
				} 
				catch (ClassNotFoundException e) 
				{
					
					object.put("error","Please retry again !");
				} 
				catch (SQLException a) 
				{
					
					object.put("error","Please give a Valid ZS_ID");
				}
			}
			
			if(object.containsKey("status")) 
			{
				RequestDispatcher rd=request.getRequestDispatcher("admin.html");
				rd.forward(request, response);
						}
			else 
			{
				out.print(object);
			}
		}
	}

