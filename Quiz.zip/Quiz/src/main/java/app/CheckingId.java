package app;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@WebServlet("/CheckingId")
public class CheckingId extends HttpServlet 
{
	private static final long serialVersionUID = 1L;
       
	static String userId;
	String admin;
   
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		
		
		String DB_URL = "jdbc:mysql://localhost:3306/QUIZ_APP";
	    String USER = "Gokul";
		String PASS = "";
		
		boolean flag = false;
		
		PrintWriter out = response.getWriter();
		userId = request.getParameter("id");

		if(userId.equals("")) 
		{
			out.print("To Join the Quiz,ZS_ID Can't be left blank ! ");
		}
		else 
		{
			try 
			{   
				String sql = "SELECT USER_ADMIN FROM QUESTIONS";
		        Class.forName("com.mysql.jdbc.Driver");
		        
	            Connection con = DriverManager.getConnection(DB_URL,USER,PASS);
	            PreparedStatement pStatement = con.prepareStatement(sql);
	      
	            ResultSet rs=pStatement.executeQuery();
	            
	       while(rs.next()) 
	       {
	    	 admin=rs.getString(1); 
	    	 if(admin.equals(userId)) 
	    	 {
	    		 flag=true;
	    		 break;
	    	 }	 
	      }
	      if(flag==true) 
	      {
	    	  response.sendRedirect("QuizPage.jsp");
	    	  out.close();
	      }
	      else 
	      {
	    	  out.print("Please enter a valid ZS_ID");
	      }
	     
		}
			catch (Exception e) 
			{
			out.print("");
		}
		}
	}
}
