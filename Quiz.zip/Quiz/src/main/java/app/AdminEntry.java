package app;

import java.io.IOException;
import java.io.PrintWriter;
import java.security.CryptoPrimitive;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@WebServlet("/AdminEntry")
public class AdminEntry extends HttpServlet 
{
	private static final long serialVersionUID = 1L;
	
	String ques,op1,op2,op3,op4,ans;
    String idMain;
	int qno;
	
	public static Connection con; 
       
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
	{
		
		PrintWriter out = response.getWriter();
		String sQno=request.getParameter("qno");
 		String question = request.getParameter("ques");
		String opt1 = request.getParameter("op1");
		String opt2 = request.getParameter("op2");
		String opt3 = request.getParameter("op3");
		String opt4 = request.getParameter("op4");
		String answer=request.getParameter("ans");
		
	    if(RegisterFormEntry.id ==null)
	    {
	    	idMain=LoginEntry.lId;
	    }
	    else if(LoginEntry.lId ==null) 
	    {
	    	idMain=RegisterFormEntry.id;
	    }
		
		
		if( sQno.equals("")|| question.equals("")|| opt1.equals("") || opt2.equals("") || opt3.equals("") || opt4.equals("") || answer.equals(""))
		{
		out.print("fails");
		}
		else 
		{
			qno = Integer.parseInt(sQno);
		ques= question.toUpperCase();
		op1= opt1.toUpperCase();
		op2= opt2.toUpperCase();
		op3= opt3.toUpperCase();
		op4= opt4.toUpperCase();
		ans= answer.toUpperCase();
		
		if(op1.equals(ans)||op2.equals(ans)||op3.equals(ans)||op4.equals(ans))
		{
			try 
			{
				Class.forName("com.mysql.cj.jdbc.Driver");
			    con = DriverManager.getConnection("jdbc:mysql://localhost:3306/QUIZ_APP","Gokul","");
			     
			    
			    
			    PreparedStatement ps = con.prepareStatement("INSERT INTO QUESTIONS(Q_NO,Question,OPTION1,OPTION2,OPTION3,OPTION4,ANSWER,USER_ADMIN) VALUES(?,?,?,?,?,?,?,?)");
			    ps.setInt(1,qno);
			    ps.setString(2,ques);
			    ps.setString(3,op1);
			    ps.setString(4,op2);
			    ps.setString(5,op3);
			    ps.setString(6,op4);
			    ps.setString(7,ans);
			    ps.setString(8,idMain);
			   
			    
			    
			    ps.executeUpdate();
			    
			    out.print("Success");
			    
			}catch (Exception e) 
			{
				out.println("Oops ! something went wriong,try again.");
			}
		}
		else 
		{
			out.print("it fails to work !");
		}
	}
	}

}
