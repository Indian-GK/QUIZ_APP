package app;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@WebServlet("/ViewPage")
public class ViewPage extends HttpServlet 
{
	private static final long serialVersionUID = 1L; 
      Connection con;
      ResultSet rs;
      int qno;
      String userId;
      String ques,op1,op2,op3,op4,ans,id;
     
      static final String DB_URL = "jdbc:mysql://localhost:3306/QUIZ_APP";
      static final String USER = "Gokul";
	  static final String PASS = "";


	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		
		PrintWriter out = response.getWriter();
		
		if(RegisterFormEntry.id ==null)
		{
	    	userId=LoginEntry.lId;
	    }
	    else if(LoginEntry.lId ==null) 
	    {
	    	userId=RegisterFormEntry.id;
	    }
		

				try 
				{   
					String sql = "SELECT * FROM QUESTIONS where USER_ADMIN = ?";
			        Class.forName("com.mysql.jdbc.Driver");
			        
		            con = DriverManager.getConnection(DB_URL,USER,PASS);
		            PreparedStatement pStatement = con.prepareStatement(sql);
		            pStatement.setString(1, userId);
		      
		            rs=pStatement.executeQuery();
		            
		      while(rs.next())
		      {
		    	  out.println(rs.getInt(1));
		    	  out.println(rs.getString(2));
		    	  out.println(rs.getString(3));
		    	  out.println(rs.getString(4));
		    	  out.println(rs.getString(5));
		    	  out.println(rs.getString(6));
		    	  out.println(rs.getString(7));
		    	  out.println(rs.getString(8));
		    	 
		      }
		      out.print(userId);
				}
				catch (Exception e) 
				{
					out.print(e);
				}     			      
	}
}

