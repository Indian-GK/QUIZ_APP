package app;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.tomcat.util.json.JSONParser;
import org.json.simple.JSONObject;

/**
 * Servlet implementation class MarkEntry
 */
@WebServlet("/MarkEntry")
public class MarkEntry extends HttpServlet {
	private static final long serialVersionUID = 1L;
	JSONParser parser = null;
   
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		
//			try {
//				PrintWriter out = response.getWriter();
//				
//				BufferedReader br = new BufferedReader(new InputStreamReader(request.getInputStream()));
//				String data = br.readLine();
//				
//				//out.println(data);
//				
//				JSONParser parser = new JSONParser(br);
//				
//				// getting data from js 
//				
//				response.setContentType("application/json");
//				JSONObject jsonObject = (JSONObject) parser.parse(data);
//				
//				// parsing the data and storing it in JSON Object
//
//				String name = (String) jsonObject.get("name");
//				
//				
//				
//				
//			}
//			catch(Exception e) {
//	    System.out.println(e.getMessage());
//			}
//			
		}
	
	}

