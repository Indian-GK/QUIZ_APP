package app;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.json.simple.JSONObject;


@WebServlet("/LoginEntry")
public class LoginEntry extends HttpServlet
{
	private static final long serialVersionUID = 1L;
       String lName;
       static String lId;

   	   public static Connection connection ;
   	   JSONObject obj = new JSONObject();
    
   
	@SuppressWarnings("unchecked")
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		
		lName=request.getParameter("name");
		lId=request.getParameter("pass");
		
	    PrintWriter out = response.getWriter();
	    
	    try
	    {
	    	
	      Class.forName("com.mysql.jdbc.Driver");
	      connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/QUIZ_APP", "Gokul", "");
	       
		    if(lName.equals("") || lId.equals(""))
		    {
	    	obj.put("error","Nothing is entered");
	         }
		    
	    else 
	    {
	  if(checkData(lName,"StudentDetails","STUDENT_NAME")==true && checkData(lId,"StudentDetails","ZS_ID")==true)
	  {
		 
		  obj.put("status","success");
		 
		 RequestDispatcher rd=request.getRequestDispatcher("admin.html");
			rd.forward(request, response);
	  }
	  else 
	  {
		  obj.put("error","Please confirm with your name and id");
	  }
	  
	    }
		    
	    }catch (Exception e) 
	    {
			obj.put("error","error while executing");
	    }
	    
	    	out.print(obj);
		}
	
	public static boolean checkData(String data, String table_name, String column_name) throws Exception
    {
        PreparedStatement preparedstatement = connection.prepareStatement("select " + column_name + " from " + table_name + " where " + column_name + " = ?;");
        preparedstatement.setString(1, data);
        ResultSet resultset = preparedstatement.executeQuery();
        resultset.next();
        
        if(resultset.getRow() >=1 && resultset.getString(column_name).equals(data))
        {
            return true;
        }
        return false;
    }      
}
